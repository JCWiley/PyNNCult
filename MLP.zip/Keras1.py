# -*- coding: utf-8 -*-
"""
Created on Fri Apr 20 12:05:59 2018

@author: John
"""

import theano
